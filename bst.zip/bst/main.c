#include <stdio.h>
#include "bst.h"

static void mostrar(const No *raiz)
{
    bst_desenhar(raiz, 0);
    printf("\nLigacoes:\n");
    bst_ligacoes(raiz);
    printf("\n");
}

int main(void)
{
    int valores[] = {50, 30, 70, 20, 40, 60, 80, 15, 35, 55, 75};
    int n = sizeof(valores) / sizeof(valores[0]);
    No *raiz = NULL;

    for (int i = 0; i < n; i++)
        raiz = bst_inserir(raiz, valores[i]);

    printf("===== a) Arvore apos as insercoes =====\n\n");
    mostrar(raiz);

    printf("===== b.1) Apos remover 30 =====\n\n");
    raiz = bst_remover(raiz, 30);
    mostrar(raiz);

    printf("===== b.2) Apos remover 50 =====\n\n");
    raiz = bst_remover(raiz, 50);
    mostrar(raiz);

    printf("===== c) Percurso em ordem =====\n\n");
    bst_em_ordem(raiz);
    printf("\n");

    bst_liberar(raiz);
    return 0;
}
