#include <stdio.h>
#include <stdlib.h>
#include "bst.h"

static No *novo_no(int valor)
{
    No *n = malloc(sizeof(No));
    if (n == NULL) {
        printf("Falha de memoria.\n");
        exit(1);
    }
    n->valor = valor;
    n->esq = n->dir = NULL;
    return n;
}

No *bst_inserir(No *raiz, int valor)
{
    if (raiz == NULL)
        return novo_no(valor);

    if (valor < raiz->valor)
        raiz->esq = bst_inserir(raiz->esq, valor);
    else if (valor > raiz->valor)
        raiz->dir = bst_inserir(raiz->dir, valor);
    /* valor repetido eh ignorado */
    return raiz;
}

static No *menor(No *raiz)
{
    while (raiz->esq != NULL)
        raiz = raiz->esq;
    return raiz;
}

No *bst_remover(No *raiz, int valor)
{
    if (raiz == NULL)
        return NULL;

    if (valor < raiz->valor) {
        raiz->esq = bst_remover(raiz->esq, valor);
    } else if (valor > raiz->valor) {
        raiz->dir = bst_remover(raiz->dir, valor);
    } else {
        /* folha ou um filho so */
        if (raiz->esq == NULL) {
            No *dir = raiz->dir;
            free(raiz);
            return dir;
        }
        if (raiz->dir == NULL) {
            No *esq = raiz->esq;
            free(raiz);
            return esq;
        }
        /* dois filhos: copia o sucessor in-order e remove ele da direita */
        No *suc = menor(raiz->dir);
        raiz->valor = suc->valor;
        raiz->dir = bst_remover(raiz->dir, suc->valor);
    }
    return raiz;
}

void bst_em_ordem(const No *raiz)
{
    if (raiz == NULL)
        return;
    bst_em_ordem(raiz->esq);
    printf("%d ", raiz->valor);
    bst_em_ordem(raiz->dir);
}

/* desenha deitada: a direita fica em cima, a esquerda embaixo */
void bst_desenhar(const No *raiz, int nivel)
{
    if (raiz == NULL)
        return;
    bst_desenhar(raiz->dir, nivel + 1);
    for (int i = 0; i < nivel; i++)
        printf("      ");
    printf("%d\n", raiz->valor);
    bst_desenhar(raiz->esq, nivel + 1);
}

void bst_ligacoes(const No *raiz)
{
    if (raiz == NULL)
        return;
    printf("  %2d: esq = ", raiz->valor);
    if (raiz->esq) printf("%2d", raiz->esq->valor); else printf(" -");
    printf(", dir = ");
    if (raiz->dir) printf("%2d", raiz->dir->valor); else printf(" -");
    printf("\n");
    bst_ligacoes(raiz->esq);
    bst_ligacoes(raiz->dir);
}

void bst_liberar(No *raiz)
{
    if (raiz == NULL)
        return;
    bst_liberar(raiz->esq);
    bst_liberar(raiz->dir);
    free(raiz);
}
