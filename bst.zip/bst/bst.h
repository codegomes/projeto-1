#ifndef BST_H
#define BST_H

typedef struct no {
    int valor;
    struct no *esq;
    struct no *dir;
} No;

No *bst_inserir(No *raiz, int valor);
No *bst_remover(No *raiz, int valor);
void bst_em_ordem(const No *raiz);
void bst_desenhar(const No *raiz, int nivel);
void bst_ligacoes(const No *raiz);
void bst_liberar(No *raiz);

#endif
