#ifndef TIPOS_H
#define TIPOS_H

#define TAM_NOME 60
#define TAM_CRM 16

typedef struct {
    int id;
    char nome[TAM_NOME];
    int idade;
} Paciente;

typedef struct {
    char nome[TAM_NOME];
    char crm[TAM_CRM];
} Medico;

typedef struct {
    Paciente paciente;
    Medico medico;
} Atendimento;

#endif
