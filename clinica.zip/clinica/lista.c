#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

typedef struct no {
    Paciente dado;
    struct no *prox;
} No;

struct lista {
    No *inicio;
    int tam;
};

Lista *lista_criar(void)
{
    Lista *l = malloc(sizeof(Lista));
    if (l == NULL)
        return NULL;
    l->inicio = NULL;
    l->tam = 0;
    return l;
}

void lista_destruir(Lista *l)
{
    No *aux = l->inicio;
    while (aux != NULL) {
        No *prox = aux->prox;
        free(aux);
        aux = prox;
    }
    free(l);
}

int lista_inserir(Lista *l, Paciente p)
{
    No *ant = NULL, *atual = l->inicio;

    while (atual != NULL && atual->dado.id < p.id) {
        ant = atual;
        atual = atual->prox;
    }
    if (atual != NULL && atual->dado.id == p.id)
        return 0;

    No *novo = malloc(sizeof(No));
    if (novo == NULL)
        return 0;
    novo->dado = p;
    novo->prox = atual;

    if (ant == NULL)
        l->inicio = novo;
    else
        ant->prox = novo;

    l->tam++;
    return 1;
}

Paciente *lista_buscar(Lista *l, int id)
{
    No *aux = l->inicio;
    while (aux != NULL && aux->dado.id < id)
        aux = aux->prox;

    if (aux != NULL && aux->dado.id == id)
        return &aux->dado;
    return NULL;
}

int lista_remover(Lista *l, int id)
{
    No *ant = NULL, *atual = l->inicio;

    while (atual != NULL && atual->dado.id != id) {
        ant = atual;
        atual = atual->prox;
    }
    if (atual == NULL)
        return 0;

    if (ant == NULL)
        l->inicio = atual->prox;
    else
        ant->prox = atual->prox;

    free(atual);
    l->tam--;
    return 1;
}

void lista_listar(const Lista *l)
{
    if (l->inicio == NULL) {
        printf("Nenhum paciente cadastrado.\n");
        return;
    }
    printf("%-6s %-30s %s\n", "ID", "Nome", "Idade");
    for (No *aux = l->inicio; aux != NULL; aux = aux->prox)
        printf("%-6d %-30s %d\n", aux->dado.id, aux->dado.nome, aux->dado.idade);
    printf("Total: %d\n", l->tam);
}

int lista_tamanho(const Lista *l)
{
    return l->tam;
}
