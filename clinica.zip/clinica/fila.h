#ifndef FILA_H
#define FILA_H

#include "tipos.h"

/* fila (FIFO) - sala de espera */
typedef struct fila Fila;

Fila *fila_criar(void);
void fila_destruir(Fila *f);

int fila_enfileirar(Fila *f, Paciente p);
int fila_desenfileirar(Fila *f, Paciente *saida);
int fila_contem(const Fila *f, int id);
int fila_vazia(const Fila *f);
int fila_tamanho(const Fila *f);
void fila_listar(const Fila *f);

#endif
