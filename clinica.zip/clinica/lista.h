#ifndef LISTA_H
#define LISTA_H

#include "tipos.h"

/* lista encadeada simples - cadastro de pacientes (ordenado por id) */
typedef struct lista Lista;

Lista *lista_criar(void);
void lista_destruir(Lista *l);

int lista_inserir(Lista *l, Paciente p);   /* retorna 0 se o id ja existe */
Paciente *lista_buscar(Lista *l, int id);  /* NULL se nao achar */
int lista_remover(Lista *l, int id);       /* retorna 0 se nao achar */
void lista_listar(const Lista *l);
int lista_tamanho(const Lista *l);

#endif
