#include <stdio.h>
#include <stdlib.h>
#include "circular.h"

typedef struct no {
    Medico dado;
    struct no *prox;
} No;

/*
 * Guardo so o ponteiro pro ultimo da rodada.
 * O plantonista atual eh sempre ultimo->prox, assim
 * inserir no fim e remover o atual ficam O(1).
 */
struct escala {
    No *ultimo;
    int tam;
};

Escala *escala_criar(void)
{
    Escala *e = malloc(sizeof(Escala));
    if (e == NULL)
        return NULL;
    e->ultimo = NULL;
    e->tam = 0;
    return e;
}

void escala_destruir(Escala *e)
{
    if (e->ultimo != NULL) {
        No *aux = e->ultimo->prox;
        e->ultimo->prox = NULL;   /* quebra o ciclo */
        while (aux != NULL) {
            No *prox = aux->prox;
            free(aux);
            aux = prox;
        }
    }
    free(e);
}

int escala_inserir(Escala *e, Medico m)
{
    No *novo = malloc(sizeof(No));
    if (novo == NULL)
        return 0;
    novo->dado = m;

    if (e->ultimo == NULL) {
        novo->prox = novo;
    } else {
        novo->prox = e->ultimo->prox;
        e->ultimo->prox = novo;
    }
    e->ultimo = novo;
    e->tam++;
    return 1;
}

const Medico *escala_atual(const Escala *e)
{
    if (e->ultimo == NULL)
        return NULL;
    return &e->ultimo->prox->dado;
}

void escala_avancar(Escala *e)
{
    if (e->ultimo != NULL)
        e->ultimo = e->ultimo->prox;
}

int escala_remover_atual(Escala *e, Medico *removido)
{
    if (e->ultimo == NULL)
        return 0;

    No *atual = e->ultimo->prox;
    if (removido != NULL)
        *removido = atual->dado;

    if (atual == e->ultimo)
        e->ultimo = NULL;
    else
        e->ultimo->prox = atual->prox;

    free(atual);
    e->tam--;
    return 1;
}

void escala_listar(const Escala *e)
{
    if (e->ultimo == NULL) {
        printf("Nenhum medico na escala.\n");
        return;
    }
    No *inicio = e->ultimo->prox;
    No *aux = inicio;
    int pos = 1;
    do {
        printf("%d. %s (CRM %s)%s\n", pos, aux->dado.nome, aux->dado.crm,
               aux == inicio ? "  <- plantao atual" : "");
        aux = aux->prox;
        pos++;
    } while (aux != inicio);
}

int escala_vazia(const Escala *e)
{
    return e->ultimo == NULL;
}
