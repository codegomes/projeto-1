#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

typedef struct no {
    Paciente dado;
    struct no *prox;
} No;

struct fila {
    No *inicio;
    No *fim;
    int tam;
};

Fila *fila_criar(void)
{
    Fila *f = malloc(sizeof(Fila));
    if (f == NULL)
        return NULL;
    f->inicio = f->fim = NULL;
    f->tam = 0;
    return f;
}

void fila_destruir(Fila *f)
{
    No *aux = f->inicio;
    while (aux != NULL) {
        No *prox = aux->prox;
        free(aux);
        aux = prox;
    }
    free(f);
}

int fila_enfileirar(Fila *f, Paciente p)
{
    No *novo = malloc(sizeof(No));
    if (novo == NULL)
        return 0;
    novo->dado = p;
    novo->prox = NULL;

    if (f->fim == NULL)
        f->inicio = novo;
    else
        f->fim->prox = novo;
    f->fim = novo;
    f->tam++;
    return 1;
}

int fila_desenfileirar(Fila *f, Paciente *saida)
{
    if (f->inicio == NULL)
        return 0;

    No *rem = f->inicio;
    *saida = rem->dado;
    f->inicio = rem->prox;
    if (f->inicio == NULL)
        f->fim = NULL;

    free(rem);
    f->tam--;
    return 1;
}

int fila_contem(const Fila *f, int id)
{
    for (No *aux = f->inicio; aux != NULL; aux = aux->prox)
        if (aux->dado.id == id)
            return 1;
    return 0;
}

int fila_vazia(const Fila *f)
{
    return f->inicio == NULL;
}

int fila_tamanho(const Fila *f)
{
    return f->tam;
}

void fila_listar(const Fila *f)
{
    if (f->inicio == NULL) {
        printf("Sala de espera vazia.\n");
        return;
    }
    int pos = 1;
    for (No *aux = f->inicio; aux != NULL; aux = aux->prox)
        printf("%d. [%d] %s\n", pos++, aux->dado.id, aux->dado.nome);
}
