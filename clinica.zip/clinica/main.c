#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lista.h"
#include "circular.h"
#include "fila.h"
#include "pilha.h"

/* ---------- leitura de entrada ---------- */

static void ler_texto(const char *msg, char *dest, int tam)
{
    printf("%s", msg);
    if (fgets(dest, tam, stdin) == NULL) {
        dest[0] = '\0';
        return;
    }
    size_t n = strlen(dest);
    if (n > 0 && dest[n - 1] == '\n')
        dest[n - 1] = '\0';
    else {
        int c;
        while ((c = getchar()) != '\n' && c != EOF)
            ;
    }
}

static int ler_int(const char *msg)
{
    char buf[32];
    char *fim;
    long v;

    for (;;) {
        ler_texto(msg, buf, sizeof buf);
        if (feof(stdin))
            exit(0);
        v = strtol(buf, &fim, 10);
        if (fim != buf && *fim == '\0')
            return (int)v;
        printf("Valor invalido, digite um numero.\n");
    }
}

/* ---------- operacoes do menu ---------- */

static void cadastrar_paciente(Lista *cad)
{
    Paciente p;
    p.id = ler_int("ID: ");
    if (lista_buscar(cad, p.id) != NULL) {
        printf("Ja existe paciente com esse ID.\n");
        return;
    }
    ler_texto("Nome: ", p.nome, TAM_NOME);
    p.idade = ler_int("Idade: ");

    if (lista_inserir(cad, p))
        printf("Paciente cadastrado.\n");
    else
        printf("Erro ao cadastrar.\n");
}

static void buscar_paciente(Lista *cad)
{
    int id = ler_int("ID: ");
    Paciente *p = lista_buscar(cad, id);
    if (p == NULL)
        printf("Paciente nao encontrado.\n");
    else
        printf("[%d] %s, %d anos\n", p->id, p->nome, p->idade);
}

static void remover_paciente(Lista *cad, Fila *espera)
{
    int id = ler_int("ID: ");
    if (fila_contem(espera, id)) {
        printf("Paciente esta na sala de espera, nao pode ser removido agora.\n");
        return;
    }
    if (lista_remover(cad, id))
        printf("Paciente removido.\n");
    else
        printf("Paciente nao encontrado.\n");
}

static void adicionar_medico(Escala *esc)
{
    Medico m;
    ler_texto("Nome do medico: ", m.nome, TAM_NOME);
    ler_texto("CRM: ", m.crm, TAM_CRM);
    if (escala_inserir(esc, m))
        printf("Medico adicionado a escala.\n");
}

static void passar_plantao(Escala *esc)
{
    if (escala_vazia(esc)) {
        printf("Escala vazia.\n");
        return;
    }
    escala_avancar(esc);
    printf("Plantao agora com Dr(a). %s\n", escala_atual(esc)->nome);
}

static void remover_plantonista(Escala *esc)
{
    Medico m;
    if (!escala_remover_atual(esc, &m)) {
        printf("Escala vazia.\n");
        return;
    }
    printf("Dr(a). %s saiu da escala.\n", m.nome);
    if (!escala_vazia(esc))
        printf("Plantao agora com Dr(a). %s\n", escala_atual(esc)->nome);
}

static void colocar_na_fila(Lista *cad, Fila *espera)
{
    int id = ler_int("ID do paciente: ");
    Paciente *p = lista_buscar(cad, id);
    if (p == NULL) {
        printf("Paciente nao cadastrado.\n");
        return;
    }
    if (fila_contem(espera, id)) {
        printf("Esse paciente ja esta na fila.\n");
        return;
    }
    fila_enfileirar(espera, *p);
    printf("%s entrou na fila (posicao %d).\n", p->nome, fila_tamanho(espera));
}

static void atender(Fila *espera, Escala *esc, Pilha *hist)
{
    if (fila_vazia(espera)) {
        printf("Ninguem na sala de espera.\n");
        return;
    }
    if (escala_vazia(esc)) {
        printf("Nenhum medico de plantao.\n");
        return;
    }

    Atendimento a;
    fila_desenfileirar(espera, &a.paciente);
    a.medico = *escala_atual(esc);
    pilha_empilhar(hist, a);

    printf("%s atendido(a) por Dr(a). %s\n", a.paciente.nome, a.medico.nome);
}

static void desfazer(Pilha *hist, Fila *espera)
{
    Atendimento a;
    if (!pilha_desempilhar(hist, &a)) {
        printf("Nada para desfazer.\n");
        return;
    }
    fila_enfileirar(espera, a.paciente);
    printf("Atendimento de %s desfeito, paciente voltou para a fila.\n", a.paciente.nome);
}

/* ---------- main ---------- */

static void menu(void)
{
    printf("\n===== Clinica VidaSaudavel =====\n");
    printf(" Pacientes\n");
    printf("  1 - Cadastrar\n");
    printf("  2 - Buscar por ID\n");
    printf("  3 - Remover\n");
    printf("  4 - Listar\n");
    printf(" Plantao\n");
    printf("  5 - Adicionar medico\n");
    printf("  6 - Passar plantao\n");
    printf("  7 - Remover plantonista atual\n");
    printf("  8 - Ver escala\n");
    printf(" Atendimento\n");
    printf("  9 - Colocar paciente na fila\n");
    printf(" 10 - Ver fila\n");
    printf(" 11 - Atender proximo\n");
    printf(" 12 - Desfazer ultimo atendimento\n");
    printf(" 13 - Ver historico\n");
    printf("  0 - Sair\n");
}

int main(void)
{
    Lista *cadastro = lista_criar();
    Escala *escala = escala_criar();
    Fila *espera = fila_criar();
    Pilha *historico = pilha_criar();

    if (!cadastro || !escala || !espera || !historico) {
        printf("Falha de memoria.\n");
        return 1;
    }

    int op;
    do {
        menu();
        op = ler_int("Opcao: ");
        printf("\n");

        switch (op) {
        case 1:  cadastrar_paciente(cadastro); break;
        case 2:  buscar_paciente(cadastro); break;
        case 3:  remover_paciente(cadastro, espera); break;
        case 4:  lista_listar(cadastro); break;
        case 5:  adicionar_medico(escala); break;
        case 6:  passar_plantao(escala); break;
        case 7:  remover_plantonista(escala); break;
        case 8:  escala_listar(escala); break;
        case 9:  colocar_na_fila(cadastro, espera); break;
        case 10: fila_listar(espera); break;
        case 11: atender(espera, escala, historico); break;
        case 12: desfazer(historico, espera); break;
        case 13: pilha_listar(historico); break;
        case 0:  printf("Encerrando...\n"); break;
        default: printf("Opcao invalida.\n");
        }
    } while (op != 0);

    lista_destruir(cadastro);
    escala_destruir(escala);
    fila_destruir(espera);
    pilha_destruir(historico);
    return 0;
}
