#ifndef PILHA_H
#define PILHA_H

#include "tipos.h"

/* pilha (LIFO) - historico de atendimentos */
typedef struct pilha Pilha;

Pilha *pilha_criar(void);
void pilha_destruir(Pilha *p);

int pilha_empilhar(Pilha *p, Atendimento a);
int pilha_desempilhar(Pilha *p, Atendimento *saida);
const Atendimento *pilha_topo(const Pilha *p);
int pilha_vazia(const Pilha *p);
void pilha_listar(const Pilha *p);

#endif
