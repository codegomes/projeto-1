#ifndef CIRCULAR_H
#define CIRCULAR_H

#include "tipos.h"

/* lista circular - escala de medicos de plantao */
typedef struct escala Escala;

Escala *escala_criar(void);
void escala_destruir(Escala *e);

int escala_inserir(Escala *e, Medico m);   /* entra no fim da rodada */
const Medico *escala_atual(const Escala *e);
void escala_avancar(Escala *e);
int escala_remover_atual(Escala *e, Medico *removido);
void escala_listar(const Escala *e);
int escala_vazia(const Escala *e);

#endif
