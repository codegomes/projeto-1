#include <stdio.h>
#include <stdlib.h>
#include "pilha.h"

typedef struct no {
    Atendimento dado;
    struct no *abaixo;
} No;

struct pilha {
    No *topo;
    int tam;
};

Pilha *pilha_criar(void)
{
    Pilha *p = malloc(sizeof(Pilha));
    if (p == NULL)
        return NULL;
    p->topo = NULL;
    p->tam = 0;
    return p;
}

void pilha_destruir(Pilha *p)
{
    No *aux = p->topo;
    while (aux != NULL) {
        No *abaixo = aux->abaixo;
        free(aux);
        aux = abaixo;
    }
    free(p);
}

int pilha_empilhar(Pilha *p, Atendimento a)
{
    No *novo = malloc(sizeof(No));
    if (novo == NULL)
        return 0;
    novo->dado = a;
    novo->abaixo = p->topo;
    p->topo = novo;
    p->tam++;
    return 1;
}

int pilha_desempilhar(Pilha *p, Atendimento *saida)
{
    if (p->topo == NULL)
        return 0;

    No *rem = p->topo;
    *saida = rem->dado;
    p->topo = rem->abaixo;
    free(rem);
    p->tam--;
    return 1;
}

const Atendimento *pilha_topo(const Pilha *p)
{
    if (p->topo == NULL)
        return NULL;
    return &p->topo->dado;
}

int pilha_vazia(const Pilha *p)
{
    return p->topo == NULL;
}

void pilha_listar(const Pilha *p)
{
    if (p->topo == NULL) {
        printf("Nenhum atendimento registrado.\n");
        return;
    }
    int n = p->tam;
    for (No *aux = p->topo; aux != NULL; aux = aux->abaixo)
        printf("#%d  %s  ->  Dr(a). %s\n", n--, aux->dado.paciente.nome, aux->dado.medico.nome);
}
